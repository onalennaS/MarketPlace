package vut.data;

public class WeightBasedProduct extends Product {

    private int weight; // in grams

    public WeightBasedProduct() {
        super();
    }

    // Constructor using super to pass inherited fields
    public WeightBasedProduct(String barcodeNumber, String productName, String productCategory, double unitPrice, int weight) {
        super(barcodeNumber, productName, productCategory);
        setUnitPrice(unitPrice);
        setWeight(weight);
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        if (weight >= 50) {
            this.weight = weight;
        } else {
            throw new IllegalArgumentException("Invalid input! Item weight must be at least 50g.");
        }
    }

    @Override
    public double calculateTotalCost() {
        // Convert grams to kg and apply tax
        double baseCost = (getUnitPrice() * getWeight()) / 1000.0;
        return baseCost * (1 + TAX_RATE);
    }

    @Override
    public String toString() {
        return super.toString() +
               ", Weight: " + getWeight() + "g" +
               ", Total Cost: R" + String.format("%.2f", calculateTotalCost());
    }
}
