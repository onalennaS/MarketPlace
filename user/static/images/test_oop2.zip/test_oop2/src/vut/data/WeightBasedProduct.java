/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vut.data;

/**
 *
 * @author Examiner
 */
public class WeightBasedProduct extends Product {

    private int weight;

    public WeightBasedProduct() {
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        if (weight >= 50) {
            this.weight = weight;
        } else {
            throw new IllegalArgumentException("Invalid input! item weight must be at least 50g");

        }
    }

    @Override
    public double calculateTotalCost() {

        double cost = getUnitPrice() * getWeight() / 1000;
        double totalCost = (cost + (cost * TAX_RATE)) / 100;
        return totalCost;

    }

}
