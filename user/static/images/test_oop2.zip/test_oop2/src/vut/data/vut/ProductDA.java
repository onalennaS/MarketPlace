package vut.data;

import java.sql.*;
import java.util.ArrayList;

public class ProductDA {

    private Connection conn;

    public ProductDA() {
        try {
            conn = getProductSalesDbConnection();
        } catch (Exception e) {
            System.out.println("Connection error: " + e.getMessage());
        }
    }

    // a. Connect to productsaledb
    public Connection getProductSalesDbConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/productsaledb";
        String user = "root"; // Update with your username
        String password = ""; // Update with your password
        return DriverManager.getConnection(url, user, password);
    }

    // b. Add a product (ItemBased or WeightBased)
    public void addProduct(Product objProduct) {
        try {
            String sql = "INSERT INTO tblproduct (Barcode_No, Product_Name, Product_Category, Manufacturer, Weight, Unit_Price, Amount_Paid) " +
                         "VALUES (?, ?, ?, ?, ?, ?, ?)";

            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, objProduct.getBarcodeNumber());
            pst.setString(2, objProduct.getProductName());
            pst.setString(3, objProduct.getProductCategory());

            if (objProduct instanceof ItemBasedProduct) {
                ItemBasedProduct ibp = (ItemBasedProduct) objProduct;
                pst.setString(4, ibp.getManufacturer());
                pst.setNull(5, Types.INTEGER); // No weight
            } else if (objProduct instanceof WeightBasedProduct) {
                WeightBasedProduct wbp = (WeightBasedProduct) objProduct;
                pst.setNull(4, Types.VARCHAR); // No manufacturer
                pst.setInt(5, wbp.getWeight());
            }

            pst.setDouble(6, objProduct.getUnitPrice());
            pst.setDouble(7, objProduct.calculateTotalCost());

            pst.executeUpdate();
            pst.close();

        } catch (SQLException e) {
            System.out.println("Error inserting product: " + e.getMessage());
        }
    }

    // c. Return all products as ArrayList
    public ArrayList<Product> returnAll() {
        ArrayList<Product> list = new ArrayList<>();

        try {
            String sql = "SELECT * FROM tblproduct";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                String barcode = rs.getString("Barcode_No");
                String name = rs.getString("Product_Name");
                String category = rs.getString("Product_Category");
                double price = rs.getDouble("Unit_Price");

                if ("IBP".equalsIgnoreCase(category)) {
                    String manufacturer = rs.getString("Manufacturer");
                    ItemBasedProduct ibp = new ItemBasedProduct(barcode, name, category, price, manufacturer);
                    list.add(ibp);
                } else if ("WBP".equalsIgnoreCase(category)) {
                    int weight = rs.getInt("Weight");
                    WeightBasedProduct wbp = new WeightBasedProduct(barcode, name, category, price, weight);
                    list.add(wbp);
                }
            }

            rs.close();
            stmt.close();

        } catch (SQLException e) {
            System.out.println("Error retrieving products: " + e.getMessage());
        }

        return list;
    }

    // d. Total of all weight-based products
    public double calculateTotalWBP() {
        double total = 0;

        try {
            String sql = "SELECT Amount_Paid FROM tblproduct WHERE Product_Category = 'WBP'";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                total += rs.getDouble("Amount_Paid");
            }

            rs.close();
            stmt.close();

        } catch (SQLException e) {
            System.out.println("Error calculating WBP total: " + e.getMessage());
        }

        return total;
    }

    // e. Total of all item-based products
    public double calculateTotalIBP() {
        double total = 0;

        try {
            String sql = "SELECT Amount_Paid FROM tblproduct WHERE Product_Category = 'IBP'";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                total += rs.getDouble("Amount_Paid");
            }

            rs.close();
            stmt.close();

        } catch (SQLException e) {
            System.out.println("Error calculating IBP total: " + e.getMessage());
        }

        return total;
    }

    // f. Update price by barcode and percentage increase
    public void updatePrice(String barcodeNumber, int percentage) {
        try {
            String selectSql = "SELECT Unit_Price FROM tblproduct WHERE Barcode_No = ?";
            PreparedStatement selectStmt = conn.prepareStatement(selectSql);
            selectStmt.setString(1, barcodeNumber);
            ResultSet rs = selectStmt.executeQuery();

            if (rs.next()) {
                double currentPrice = rs.getDouble("Unit_Price");
                double newPrice = currentPrice + (currentPrice * percentage / 100.0);

                String updateSql = "UPDATE tblproduct SET Unit_Price = ?, Amount_Paid = Unit_Price * (1 + 0.15) WHERE Barcode_No = ?";
                PreparedStatement updateStmt = conn.prepareStatement(updateSql);
                updateStmt.setDouble(1, newPrice);
                updateStmt.setString(2, barcodeNumber);
                updateStmt.executeUpdate();
                updateStmt.close();
            }

            rs.close();
            selectStmt.close();

        } catch (SQLException e) {
            System.out.println("Error updating price: " + e.getMessage());
        }
    }

    // g. Return list of barcodes only
    public ArrayList<String> returnBarcodes() {
        ArrayList<String> barcodes = new ArrayList<>();

        try {
            String sql = "SELECT Barcode_No FROM tblproduct";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                barcodes.add(rs.getString("Barcode_No"));
            }

            rs.close();
            stmt.close();

        } catch (SQLException e) {
            System.out.println("Error retrieving barcodes: " + e.getMessage());
        }

        return barcodes;
    }
}
