/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vut.data;

import java.util.ArrayList;

/**
 *
 * @author Examiner
 */
public abstract class Product {    
    

    protected String barcodeNumber;
    protected String productName;
    protected int unitPrice;
    protected static final double TAX_RATE = 0.15;
   
    protected double totalCost;

   // public Product() {this(" "," ",ProductCategory.IBP,100);}

    
    
   
    

    public String getBarcodeNumber() {return barcodeNumber;}
    public void setBarcodeNumber(String barcodeNumber) {this.barcodeNumber = barcodeNumber;}
    public String getProductName() {return productName; }
    public void setProductName(String productName) {this.productName = productName; }    
    public int getUnitPrice() {return unitPrice; }
    public void setUnitPrice(int unitPrice) {this.unitPrice = unitPrice;}
   
    public double getTotalCost() { return totalCost;}
   public void setTotalCost(double totalCost) {this.totalCost = totalCost; }    
    
    public abstract double calculateTotalCost();   

}


