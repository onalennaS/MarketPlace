package vut.data;

public class ItemBasedProduct extends Product {

    private String manufacturer;

    public ItemBasedProduct() {
        super();
    }

    // Constructor that uses super to pass inherited fields
    public ItemBasedProduct(String barcodeNumber, String productName, String productCategory, double unitPrice, String manufacturer) {
        super(barcodeNumber, productName, productCategory);
        setUnitPrice(unitPrice);
        setManufacturer(manufacturer);
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        if (manufacturer.length() >= 4) {
            this.manufacturer = manufacturer;
        } else {
            throw new IllegalArgumentException("Invalid input! Manufacturer name too short, must have at least 4 characters.");
        }
    }

    @Override
    public double calculateTotalCost() {
        return getUnitPrice() * (1 + TAX_RATE);
    }

    @Override
    public String toString() {
        return super.toString() +
               ", Manufacturer: " + getManufacturer() +
               ", Total Cost: R" + String.format("%.2f", calculateTotalCost());
    }
}
