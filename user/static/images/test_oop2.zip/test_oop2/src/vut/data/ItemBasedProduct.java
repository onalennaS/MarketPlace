/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vut.data;

/**
 *
 * @author Examiner
 */
public class ItemBasedProduct extends Product {

    private String manufacturer;

    public ItemBasedProduct() {
    }

    public void setManufacturer(String manufacturer) {
        if (manufacturer.length() >= 4) {
            this.manufacturer = manufacturer;
        } else {
            throw new IllegalArgumentException("Invalid input! manufacturer name too shot, must have at least 4 characters");
        }
    }

    public String getManufacturer() {
        return manufacturer;
    }

    @Override
    public double calculateTotalCost() {

        return (getUnitPrice() + (getUnitPrice() * TAX_RATE)) / 100;

    }

}
