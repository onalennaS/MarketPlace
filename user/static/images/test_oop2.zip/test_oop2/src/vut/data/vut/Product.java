package vut.data;

public abstract class Product {

    protected String barcodeNumber;
    protected String productName;
    protected String productCategory;
    protected double unitPrice;
    protected static final double TAX_RATE = 0.15;

    public Product() {
    }

    // Constructor with 3 parameters (requirement 3)
    public Product(String barcodeNumber, String productName, String productCategory) {
        this.barcodeNumber = barcodeNumber;
        this.productName = productName;
        this.productCategory = productCategory;
    }

    // Overloaded constructor with totalCost as 5th parameter (requirement 5)
    public Product(String barcodeNumber, String productName, String productCategory, double unitPrice, double totalCost) {
        this.barcodeNumber = barcodeNumber;
        this.productName = productName;
        this.productCategory = productCategory;
        this.unitPrice = unitPrice;
        // totalCost is not stored in the parent class anymore — subclasses calculate it
        // You can store it in a subclass or ignore it if calculateTotalCost is used directly
    }

    // Getters and Setters
    public String getBarcodeNumber() {
        return barcodeNumber;
    }

    public void setBarcodeNumber(String barcodeNumber) {
        this.barcodeNumber = barcodeNumber;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductCategory() {
        return productCategory;
    }

    public void setProductCategory(String productCategory) {
        this.productCategory = productCategory;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    // Abstract method to be implemented in subclasses
    public abstract double calculateTotalCost();

    // toString() method using getters
    @Override
    public String toString() {
        return "Barcode: " + getBarcodeNumber() +
               ", Name: " + getProductName() +
               ", Category: " + getProductCategory() +
               ", Unit Price: R" + getUnitPrice();
    }
}
